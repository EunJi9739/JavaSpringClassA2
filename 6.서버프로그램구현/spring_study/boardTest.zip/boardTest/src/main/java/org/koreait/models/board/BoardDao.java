package org.koreait.models.board;

import org.koreait.controllers.board.BoardForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
@Transactional
public class BoardDao {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    public void insert(BoardForm boardForm){
        KeyHolder keyHolder = new GeneratedKeyHolder();

        String sql = "INSERT INTO BOARD0523(ID, SUBJECT, CONTENT) VALUES (BOARD0523_SEQ.nextval, ?, ?)";

        jdbcTemplate.update(conn -> {
            PreparedStatement ps = conn.prepareStatement(sql, new String[] {"ID"});

            ps.setString(1, boardForm.getContent());
            ps.setString(2, boardForm.getSubject());

            return ps;
        },keyHolder);

        Number key = keyHolder.getKey();
        boardForm.setId(key.longValue());
    }

    public Board get(long id){
        try{
            String sql = "SELECT * FROM BOARD0523 WHERE ID = ?";
            Board board = jdbcTemplate.queryForObject(sql,this::mapper,id);
            return board;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }

    }

    private Board mapper(ResultSet rs, int i) throws SQLException {
        Board board = new Board();

        board.setId(rs.getLong("ID"));
        board.setSubject(rs.getString("SUBJECT"));
        board.setContent(rs.getString("CONTENT"));
        board.setRegDt(rs.getTimestamp("REGDT").toLocalDateTime());

        return board;
        

    }

    public List<Board> gets(){
        String sql="SELECT * FROM BOARD0523 ORDER BY REGDT DESC";

        List<Board> items = jdbcTemplate.query(sql,this::mapper);

        return items;
    }

    public void processSchedule(){
        try{
            String sql = "SELECT COUNT(*), SUBSTR(REGDT, 1, 10) FROM BOARD0523 WHERE REGDT >= REGDT -1 GROUP BY SUBSTR(REGDT,1,13)";

            List<Board> sd = jdbcTemplate.query(sql,this::mapper);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

}
