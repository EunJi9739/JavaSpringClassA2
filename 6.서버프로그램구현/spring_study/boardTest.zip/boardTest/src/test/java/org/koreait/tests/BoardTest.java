package org.koreait.tests;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.koreait.controllers.board.BoardForm;
import org.koreait.models.board.Board;
import org.koreait.models.board.BoardDao;
import org.koreait.models.board.BoardSaveService;
import org.koreait.models.board.BoardValidationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import static org.junit.jupiter.api.Assertions.*;

@Transactional
@SpringBootTest
public class BoardTest {

    @Autowired
    private BoardSaveService saveService;
    @Autowired
    private BoardDao boardDao;

    private BoardForm getBoardForm(){
        BoardForm bf = new BoardForm();
        bf.setSubject("제목입니다.");
        bf.setContent("내용입니다.");


        return bf;

    }

    @Test
    @DisplayName("게시판 저장 기능 확인")
    void boardSaveSuccessTest(){
        assertDoesNotThrow(() -> {
            BoardForm bf = getBoardForm();
            saveService.save(bf);
        });
    }

    @Test
    @DisplayName("게시판 항목 필수 입력 확인 - 실패 시 BoardValidationException 발생")
    void requiredFieldTest(){
        assertAll(
                //content -> null
                () -> assertThrows(BoardValidationException.class, () -> {
                    BoardForm bf = getBoardForm();
                    bf.setContent(null);
                    saveService.save(bf);
                }),
                //content -> 빈 값
                () -> assertThrows(BoardValidationException.class, () -> {
                    BoardForm bf = getBoardForm();
                    bf.setContent("    ");
                    saveService.save(bf);
                }),
                //subject -> null
                () -> assertThrows(BoardValidationException.class, () -> {
                    BoardForm bf = getBoardForm();
                    bf.setSubject(null);
                    saveService.save(bf);
                }),

                //subject -> 빈값
                () -> assertThrows(BoardValidationException.class, () -> {
                    BoardForm bf = getBoardForm();
                    bf.setSubject("   ");
                    saveService.save(bf);
                })
        );

    }

    @Test
    @DisplayName("저장한 게시글이 일치하는지 확인")
    void boardEqualsTest(){
        BoardForm bf = getBoardForm();
        assertDoesNotThrow(() -> {
           boardDao.insert(bf);
        });

        Long id=bf.getId();
        if(id==null){
            //저장된 게시글이 없으면 실패
            fail();
        }

        Board board = boardDao.get(id);
        if(board==null){
            //조회되는 게시글이 없으면 실패
            fail();
        }

        assertEquals(bf.getContent(),board.getContent());
        assertEquals(bf.getSubject(),board.getSubject());
    }
}
