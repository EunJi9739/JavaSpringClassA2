package models.member;

public class JoinService {

}
